{{-- @extends('layouts.app')

@section('content')
    <h2>HALAMAN TAMU</h2>
@endsection --}}
