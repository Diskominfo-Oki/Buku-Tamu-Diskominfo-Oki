<div class="alert alert-warning alert-dismissible fade show text-white" role="alert">
    <strong class="text-white">Perhatian! </strong> {{ $alert }}
</div>
