<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; @php echo date('Y'); @endphp
        <div class="bullet"></div>
        <span>buku tamu DISKOMINFO OKI</span>
    </div>
    <div class="footer-right">Version 1</div>
</footer>
