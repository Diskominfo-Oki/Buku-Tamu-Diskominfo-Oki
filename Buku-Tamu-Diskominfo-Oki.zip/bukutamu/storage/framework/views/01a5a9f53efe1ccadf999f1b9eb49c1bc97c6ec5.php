<h2 class="text-center mb-5 title_ku">DINAS KOMUNIKASI DAN INFORMATIKA KABUPATEN OGAN
    KOMERING ILIR
</h2>
<?php /**PATH D:\buku_tamu\resources\views/components/title.blade.php ENDPATH**/ ?>