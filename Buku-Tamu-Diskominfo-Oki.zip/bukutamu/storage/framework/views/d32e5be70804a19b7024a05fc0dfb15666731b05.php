<div class="alert alert-warning alert-dismissible fade show text-white" role="alert">
    <strong class="text-white">Perhatian! </strong> <?php echo e($alert); ?>

</div>
<?php /**PATH /var/www/html/bukutamu/resources/views/components/alertForm.blade.php ENDPATH**/ ?>