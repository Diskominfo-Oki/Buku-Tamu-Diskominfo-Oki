<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?php echo date('Y'); ?>
        <div class="bullet"></div>
        <span>buku tamu DISKOMINFO OKI</span>
    </div>
    <div class="footer-right">Version 1</div>
</footer>
<?php /**PATH D:\buku_tamu\resources\views/layouts/footer.blade.php ENDPATH**/ ?>